This folder contains two files:

1. AdriàCasanova-VíctorGarcia-ZhengyongJi.Rmd
	This Rmarkdown file generates the report of the assignment.

2. profiling_func.R
	An R file containing a function we have used in AdriàCasanova-VíctorGarcia-ZhengyongJi.Rmd to profile the target. Therefore, to execute the previous file, this file has to be in the working directory of the R session,